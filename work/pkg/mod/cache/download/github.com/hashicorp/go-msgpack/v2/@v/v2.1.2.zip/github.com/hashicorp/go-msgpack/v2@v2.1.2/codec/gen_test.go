//go:build codecgen.exec

package codec

import "testing"

// TestDontPanic checks that the code compiles with this tag.
func TestDontPanic(t *testing.T) {}
